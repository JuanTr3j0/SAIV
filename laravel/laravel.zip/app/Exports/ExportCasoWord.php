<?php
namespace App\Exports;

class ExportCasoWord
{

}