<?php

namespace App\Http\Controllers;

use App\Models\ResponsablesCasos;
use Illuminate\Http\Request;

class ResponsablesCasosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ResponsablesCasos  $responsablesCasos
     * @return \Illuminate\Http\Response
     */
    public function show(ResponsablesCasos $responsablesCasos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ResponsablesCasos  $responsablesCasos
     * @return \Illuminate\Http\Response
     */
    public function edit(ResponsablesCasos $responsablesCasos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ResponsablesCasos  $responsablesCasos
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ResponsablesCasos $responsablesCasos)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ResponsablesCasos  $responsablesCasos
     * @return \Illuminate\Http\Response
     */
    public function destroy(ResponsablesCasos $responsablesCasos)
    {
        //
    }
}
