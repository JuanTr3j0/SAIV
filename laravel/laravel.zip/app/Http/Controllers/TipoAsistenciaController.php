<?php

namespace App\Http\Controllers;

use App\Models\TipoAsistencia;
use App\Http\Requests\StoreTipoAsistenciaRequest;
use App\Http\Requests\UpdateTipoAsistenciaRequest;

class TipoAsistenciaController extends Controller
{  
}